const cli = require("./lib/watch.js")
cli.start();